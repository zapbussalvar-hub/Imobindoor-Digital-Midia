
// Painel avançado com GitHub API
// O TOKEN NÃO É GRAVADO NO CÓDIGO – o usuário digita uma vez e fica só no localStorage

const GitHubAPI = {
  getToken() {
    return localStorage.getItem("gh_token") || "";
  },
  setToken(t) {
    localStorage.setItem("gh_token", t.trim());
  },
  async request(method, path, body=null) {
    const token = GitHubAPI.getToken();
    if (!token) throw new Error("Token não configurado no painel.");
    const res = await fetch("https://api.github.com" + path, {
      method,
      headers: {
        "Authorization": "token " + token,
        "Accept": "application/vnd.github+json"
      },
      body: body ? JSON.stringify(body) : null
    });
    if (!res.ok) throw new Error("Falha GitHub API: " + res.status);
    return await res.json();
  }
};

window.ImobPainel = {
  init() {},
  configurarToken() {
    const t = prompt("Cole seu token do GitHub:");
    if (t) {
      GitHubAPI.setToken(t);
      alert("Token configurado com sucesso.");
    }
  },
  async enviarMidia(file) {
    const reader = new FileReader();
    reader.onload = async () => {
      const content = btoa(reader.result);
      await GitHubAPI.request("PUT",
        "/repos/zapbussalvar-hub/Imobindoor/contents/media/" + file.name,
        { message:"upload", content }
      );
      alert("Mídia enviada com sucesso.");
    };
    reader.readAsBinaryString(file);
  },
  async excluirMidia(nome) {
    const fileInfo = await fetch(
      "https://api.github.com/repos/zapbussalvar-hub/Imobindoor/contents/media/" + nome
    ).then(r=>r.json());
    await GitHubAPI.request("DELETE",
      "/repos/zapbussalvar-hub/Imobindoor/contents/media/" + nome,
      { message:"delete", sha:fileInfo.sha }
    );
    alert("Arquivo excluído.");
  },
  async salvarPlaylist(jsonData) {
    const current = await fetch(
      "https://api.github.com/repos/zapbussalvar-hub/Imobindoor/contents/playlist.json"
    ).then(r=>r.json());

    await GitHubAPI.request("PUT",
      "/repos/zapbussalvar-hub/Imobindoor/contents/playlist.json",
      {
        message:"update playlist",
        content:btoa(JSON.stringify(jsonData,null,2)),
        sha:current.sha
      }
    );
    alert("Playlist atualizada.");
  }
};
